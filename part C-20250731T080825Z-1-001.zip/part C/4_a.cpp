#include <iostream>
using namespace std;

int main()
{   
    int arr[] = {1,2,3,4,5},i;

    cout<<"TRAVERSAL OF AN ARRAY : \n";
    for(i = 0;i < 5;i++)
    {
        cout<<arr[i]<<" ";
    }

    return 0;
}